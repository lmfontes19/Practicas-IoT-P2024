package com.example.testubi2

data class DeviceClass
    (val name : String,
     val photo : String)